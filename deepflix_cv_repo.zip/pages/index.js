import DeepflixCV from "../components/DeepflixCV";

export default function Home() {
  return <DeepflixCV />;
}
